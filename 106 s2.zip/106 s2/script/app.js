
// global functions
var important = false;
var serverUrl = "https://fsdiapi.azurewebsites.net/";

// HW variable scope on JS




function toggleImportant(){
    //  change icon if selected
    if(!important) {
        important = true;
        // chain the element together
        $("#iImportant").removeClass("far").addClass("fas");
    }

    else {
        important = false;
        $("#iImportant").removeClass("fas").addClass("far");
    }
}

function saveTask (){
    // read values from the controls
    let title = $("#txtTitle").val();
    let category = $("#selCategory").val();
    let description = $("#txtDescription").val();
    let location = $("#txtLocation").val();
    let dueDate = $("#selDueDate").val();
    let color = $("#selColor").val();

    let task = new Task (title ,important, category , description , location , dueDate, color );
    console.log(task);

    // send object to backend server

    $.ajax({
        url: serverUrl + "api/tasks/",
        type: 'POST',
        data: JSON.stringify(task),
        contentType: "application/json",
        sucess: function(res){
          console.log("server says:", res)
        },


        error: function(eDetails) {
            console.error("error saving", eDetails);

        }
          
    });
    // get-retrive dont allow data

    // post-create new
    // put-part of data
    // patch- modifly entire page
    // delet- remove





    // display the task 

    displayTask(task);

   function displayTask (task) {
       let syntax =
       `<div class="task"> 
       <i class='imporant class= 'fas-fa-star></i> 
       </div>

        <div> 
        <h5 class='description'>${task.title} </h5>
        <p>${task.description} </p>
        </div>

        <div>
        <label class='due-date'>${task.dueDate}</label>
        <label class= 'loaction'>${task.location}</label>
        </div>
       `;


       $("#pendingList").append(syntax);
   }

}

function init(){

    // load data
    console.log("My Task Manger");
    // hook events
    // use Jquery to select the element using the$ then .click and what function to excute.
    $("#iImportant").click(toggleImportant);
    $("#btnsave").click(saveTask);
}

window.onload = init;




