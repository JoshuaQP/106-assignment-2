class Task {
    constructor(title, important, description, category, location, dueDate, color) {
        this.title = title;
        this.important = important;
        this.category = category;
        this.description = desc;
        this.location = location;
        this.dueDate = dueDate;
        this.color = color;
        this.name = "joshua";
    }
}
